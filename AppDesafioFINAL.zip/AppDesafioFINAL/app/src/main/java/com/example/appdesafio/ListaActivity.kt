package com.example.appdesafio

import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_lista.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.noButton
import org.jetbrains.anko.yesButton

import java.util.ArrayList

import javax.security.auth.login.LoginException

class ListaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista)

        val language = arrayOf<String>(
                "Mágica na garrafa","Promoção","Black Friday","Vinho Branco","Vinho Rosé","Vinho Tinto","Vinho suave",
                "Espumantes","Champanhe","Chardonnay","Merlot","Pinot Noir")
        val description = arrayOf<String>(
                "Dê um gole e se delicie com essa novidade.",
                "Chega de pagar caro no seu vinho preferido.",
                "Venha ver em primeira mão os nossos megas descontos.",
                "Vinho com coloração variando do mais pálido amarelo-esverdeado até o mais profundo dourado-âmbar.",
                "Vinho que apresenta coloração rosada, intermediária entre os tintos e os brancos.",
                "Bebida resultante da fermentação do suco ou mosto extraído de uvas pretas ou tintas.",
                "Classificação de vinho aplicado às bebidas que possuem mais de 20 gramas de açúcar por litro.",
                "Tipo de vinho que tem nível significativo de dióxido de carbono, fazendo-o borbulhar quando servido.",
                "Vinho branco espumante, produzido na região de Champagne, através da fermentação da uva.",
                "Uva da família da Vitis vinifera, a partir da qual é fabricado vinho branco de qualidade.",
                "É uma casta de uva tinta, fruto da Vitis vinifera.",
                "É conhecida por gerar vinhos delicados, frescos e também ricos em aromas."
        )

        val imageId = arrayOf<Int>(
                R.drawable.img1,R.drawable.img2,R.drawable.img3,
                R.drawable.img1,R.drawable.img2,R.drawable.img3,
                R.drawable.img1,R.drawable.img2,R.drawable.img3,
                R.drawable.img1,R.drawable.img2,R.drawable.img3
        )


            val myListAdapter = ListAdapter(this,language,description,imageId)
        lvLista.adapter = myListAdapter

        lvLista.setOnItemClickListener(){adapterView, view, position, id ->
                val itemAtPos = adapterView.getItemAtPosition(position)
                val itemIdAtPos = adapterView.getItemIdAtPosition(position)
                Toast.makeText(this, "Click on item at $itemAtPos its item id $itemIdAtPos", Toast.LENGTH_LONG).show()

        }


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menuLogout -> {

                alert("Deseja realmente sair ?") {
                    yesButton {
                        try {
                            SharedPrefManager.getInstance(this@ListaActivity)!!.logout()
                            finish()
                        } catch (e: LoginException) {
                            e.printStackTrace()
                        }
                    }
                    noButton {}
                }.show()
            }
        }
        return true
    }

}
