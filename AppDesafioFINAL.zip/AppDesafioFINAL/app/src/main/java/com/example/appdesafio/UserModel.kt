package com.example.appdesafio

internal class UserModel {
    val name: Any?
        get() = null

    val age: Any?
        get() = null

    fun incrementAge() {

    }
}
