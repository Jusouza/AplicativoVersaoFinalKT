package com.example.appdesafio

import java.security.AuthProvider

internal object SharedPrefManager {
    fun getInstance(listaActivity: ListaActivity): AuthProvider? {
        return null
    }
}
