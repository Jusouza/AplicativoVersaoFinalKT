package com.example.appdesafio

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class ListAdapter(private val context: Activity, private val title: Array<String>, private val description: Array<String>, private val imgid: Array<Int>)
    : ArrayAdapter<String>(context, R.layout.item_list, title) {

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.item_list, null, true)

        val titleText = rowView.findViewById(R.id.titulo) as TextView
        val descText = rowView.findViewById(R.id.descricao) as TextView
        val imageView = rowView.findViewById(R.id.image) as ImageView

        imageView.setImageResource(imgid[position])
        titleText.text = title[position]
        descText.text = description[position]

        return rowView
    }
}