package com.example.appdesafio

data class Lista(var titulo: String, var descricao: String, var imagem: Int)