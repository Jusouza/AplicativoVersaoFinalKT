package com.example.appdesafio


import androidx.appcompat.app.AppCompatActivity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.*
import kotlinx.android.synthetic.main.activity_lista.*
import kotlinx.android.synthetic.main.activity_main.*


import java.util.ArrayList


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //login
        et_email.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(content: Editable) {
                if (et_email.text == et_password.text) {
                    startActivity(Intent(applicationContext, ListaActivity::class.java))
                }

                val message = "E-mail inválido"

                et_email.error =
                        if (content.isNotEmpty()
                                && Patterns.EMAIL_ADDRESS.matcher(content).matches())
                            null
                        else
                            message
            }

            override fun beforeTextChanged(
                    content: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int) {
            }

            override fun onTextChanged(
                    content: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int) {
            }
        })
        //senha login
        et_password.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(content: Editable) {

                val message = "Senha inválida"

                et_password.error =
                        if (content.length > 5)
                            null
                        else
                            message
            }

            override fun beforeTextChanged(
                    content: CharSequence?,
                    start: Int,
                    count: Int,
                    after: Int) {
            }

            override fun onTextChanged(
                    content: CharSequence?,
                    start: Int,
                    before: Int,
                    count: Int) {
            }
        })


        bt_login.setOnClickListener {
            startActivity(Intent(applicationContext, ListaActivity::class.java))

        }

        fun alert(s: String) {
            Toast.makeText(this, s, Toast.LENGTH_LONG).show()
        }



    }
}
